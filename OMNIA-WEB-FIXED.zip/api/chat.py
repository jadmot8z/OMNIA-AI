from http.server import BaseHTTPRequestHandler
import json

class handler(BaseHTTPRequestHandler):
    def do_POST(self):
        length=int(self.headers.get("content-length",0))
        data=json.loads(self.rfile.read(length))
        msg=data.get("message","")

        response={
            "answer":"OMNIA : "+msg,
            "status":"success"
        }

        self.send_response(200)
        self.send_header("Content-Type","application/json")
        self.end_headers()
        self.wfile.write(json.dumps(response).encode())